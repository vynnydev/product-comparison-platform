import boto3
import json
from datetime import datetime, timedelta

def handler(event, context):
    ce = boto3.client('ce')
    cloudwatch = boto3.client('cloudwatch')
    
    # Datas
    end_date = datetime.now().strftime('%Y-%m-%d')
    start_date = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')
    
    project_name = event.get('PROJECT_NAME', 'product-comparison')
    
    # Obter custos por serviço
    response = ce.get_cost_and_usage(
        TimePeriod={
            'Start': start_date,
            'End': end_date
        },
        Granularity='DAILY',
        Metrics=['UnblendedCost'],
        GroupBy=[
            {'Type': 'DIMENSION', 'Key': 'SERVICE'}
        ],
        Filter={
            'Tags': {
                'Key': 'Project',
                'Values': [project_name]
            }
        }
    )
    
    # Processar e enviar métricas
    for result in response['ResultsByTime']:
        date = result['TimePeriod']['Start']
        
        for group in result['Groups']:
            service = group['Keys'][0]
            cost = float(group['Metrics']['UnblendedCost']['Amount'])
            
            # Enviar para CloudWatch
            cloudwatch.put_metric_data(
                Namespace='FinOps/Costs',
                MetricData=[
                    {
                        'MetricName': 'DailyCost',
                        'Dimensions': [
                            {'Name': 'Project', 'Value': project_name},
                            {'Name': 'Service', 'Value': service}
                        ],
                        'Value': cost,
                        'Unit': 'None',
                        'Timestamp': datetime.strptime(date, '%Y-%m-%d')
                    }
                ]
            )
    
    # Obter custo total do mês
    month_start = datetime.now().replace(day=1).strftime('%Y-%m-%d')
    
    total_response = ce.get_cost_and_usage(
        TimePeriod={
            'Start': month_start,
            'End': end_date
        },
        Granularity='MONTHLY',
        Metrics=['UnblendedCost'],
        Filter={
            'Tags': {
                'Key': 'Project',
                'Values': [project_name]
            }
        }
    )
    
    total_cost = 0
    for result in total_response['ResultsByTime']:
        total_cost = float(result['Total']['UnblendedCost']['Amount'])
    
    cloudwatch.put_metric_data(
        Namespace='FinOps/Costs',
        MetricData=[
            {
                'MetricName': 'MonthlyTotalCost',
                'Dimensions': [
                    {'Name': 'Project', 'Value': project_name}
                ],
                'Value': total_cost,
                'Unit': 'None'
            }
        ]
    )
    
    # Obter forecast
    try:
        forecast_response = ce.get_cost_forecast(
            TimePeriod={
                'Start': end_date,
                'End': (datetime.now().replace(day=1) + timedelta(days=32)).replace(day=1).strftime('%Y-%m-%d')
            },
            Metric='UNBLENDED_COST',
            Granularity='MONTHLY',
            Filter={
                'Tags': {
                    'Key': 'Project',
                    'Values': [project_name]
                }
            }
        )
        
        forecast_cost = float(forecast_response['Total']['Amount'])
        
        cloudwatch.put_metric_data(
            Namespace='FinOps/Costs',
            MetricData=[
                {
                    'MetricName': 'MonthlyForecast',
                    'Dimensions': [
                        {'Name': 'Project', 'Value': project_name}
                    ],
                    'Value': forecast_cost,
                    'Unit': 'None'
                }
            ]
        )
    except Exception as e:
        print(f"Forecast error: {e}")
    
    return {
        'statusCode': 200,
        'body': json.dumps({
            'message': 'Cost metrics exported successfully',
            'total_cost': total_cost
        })
    }
